# Task05G Model Confidence + Selector V2 Scorecard

Verdict: `V2_EXPERIMENT_VALIDATED`

Preregistration commit: `a6a0fb5cb4d4f742ef6d2708f17c8aac7ba5bf44`
Preregistration blob: `d06d64c4aa94d1c4d291f585af5e42003a86a49d`

## Development (2020-2022)

| Lane | Plays | Coverage | Hit rate | ROI |
|---|---:|---:|---:|---:|
| HHR V2 | 56 | 86.2% | 58.2% | +7.22% |
| Value V2 | 54 | 83.1% | 51.9% | +11.90% |
| HHR V1 | 29 | 44.6% | 69.0% | +4.35% |
| Balanced V1 | 30 | 46.2% | 56.7% | +3.42% |
| Value V1 | 32 | 49.2% | 34.4% | -16.73% |

### Balanced grid

| Variant | Tolerance | Plays | Coverage | Hit rate | ROI | Pass |
|---|---:|---:|---:|---:|---:|:---:|
| B0 | +0.0% | 56 | 86.2% | 58.2% | +9.62% | YES |
| B1 | -1.0% | 56 | 86.2% | 58.2% | +9.62% | YES |
| B2 | -2.0% | 56 | 86.2% | 58.2% | +9.62% | YES |

Balanced decision: `WINNER_FROZEN_FROM_2020_2022`
Frozen winner: `B0`

## Confirmation (2023-2024)


| Lane | Plays | Coverage | Hit rate | ROI |
|---|---:|---:|---:|---:|
| HHR V2 | 44 | 100.0% | 47.7% | -15.04% |
| Balanced V2 | 44 | 100.0% | 47.7% | -11.19% |
| Value V2 | 40 | 90.9% | 41.0% | -20.30% |

## Coverage guardrails

- HHR V2 development coverage guardrail: `PASS`
- Value V2 development coverage warning: `PASS`

## Holdout

2025 remained sealed and was not loaded into eligible experiment data.
